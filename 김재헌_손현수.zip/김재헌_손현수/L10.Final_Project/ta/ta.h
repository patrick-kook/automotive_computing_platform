// 1. Modify macro variable name(header guard), if needed.
#ifndef TA_H
#define TA_H


// 3. Modify command ID.
#define CMD_SAVE 0
#define CMD_LOAD 1
#define CMD_DELETE 2
#define CMD_GENERATE_PUBLIC_KEY 3
#define CMD_SIGN 4
#define CMD_VERIFY 5


#endif
